import base64
import hashlib
from Cryptodome import Random
from Cryptodome.Cipher import AES
from Cryptodome.Cipher.AES import MODE_CBC
import os
from dotenv import load_dotenv
import struct
from io import BytesIO
from decouple import config


class AESCipher(object):
    def __init__(self, key=None):
        load_dotenv()
        if not key:
            key = config("KEY")
        self.chunk_size = int(config("CHUNK_SIZE"))
        self.bs = AES.block_size
        self.key = hashlib.sha256(key.encode()).digest()

    def _read_file(self, path):
        with open(path, "rb") as f:
            content = f.read()
        return content

    def _encrypt_text(self, raw):
        raw = self._pad(raw)
        iv = Random.new().read(AES.block_size)
        cipher = AES.new(self.key, AES.MODE_GCM, iv)
        return base64.b64encode(iv + cipher.encrypt(raw.encode()))

    def _decrypt_text(self, enc):
        enc = base64.b64decode(enc)
        iv = enc[: AES.block_size]
        cipher = AES.new(self.key, AES.MODE_GCM, iv)
        decrypted_file = self._unpad(cipher.decrypt(enc[AES.block_size :]))
        return decrypted_file

    def _encrypt_file(self, infile, encfile):
        content = self._read_file(infile)
        content_file = BytesIO(content)
        iv = Random.new().read(AES.block_size)
        aes = AES.new(self.key, AES.MODE_GCM, iv)
        file_size = os.path.getsize(infile)
        with open(encfile, "wb") as fout:
            fout.write(struct.pack("<Q", file_size))
            fout.write(iv)

            while True:
                data = content_file.read(self.chunk_size)
                n = len(data)
                if n == 0:
                    break
                elif n % 16 != 0:
                    data += b" " * (16 - n % 16)
                encd = aes.encrypt(data)
                fout.write(encd)

    def _decrypt_file(self, encfile, outfile):
        with open(encfile, "rb") as fin:
            file_size = struct.unpack("<Q", fin.read(struct.calcsize("<Q")))[0]
            iv = fin.read(16)
            aes = AES.new(self.key, AES.MODE_GCM, iv)
            with open(outfile, "wb") as fout:
                while True:
                    data = fin.read(self.chunk_size)
                    n = len(data)
                    if n == 0:
                        break
                    decd = aes.decrypt(data)
                    n = len(decd)
                    if file_size > n:
                        fout.write(decd)
                    else:
                        fout.write(decd[:file_size])
                    file_size -= n
        return base64.b64encode(outfile)

    def _pad(self, s):
        return s + (self.bs - len(s) % self.bs) * chr(self.bs - len(s) % self.bs)

    @staticmethod
    def _unpad(s):
        return s[: -ord(s[len(s) - 1 :])]

    def encrypt(self, *args):
        if len(args) == 1:
            try:
                for i in args:
                    return self._encrypt_text(i)
            except Exception:
                return "Criptografia de textos em formato string apenas"
        else:
            try:

                lista = list()
                for i in args:
                    lista.append(i)

                return self._encrypt_file(infile=lista[0], encfile=lista[1])
            except Exception:
                return "Problemas com a criptografia do arquivo."

    def decrypt(self, *args):
        if len(args) == 1:
            try:
                for i in args:
                    return str(self._decrypt_text(i), "utf-8")
            except Exception:
                return "Informe no formato de bytes."
        else:
            try:
                lista = list()
                for i in args:
                    lista.append(i)
                return self._decrypt_file(encfile=lista[0], outfile=lista[1])
            except Exception:
                return "Problemas com a descriptografia do arquivo."
